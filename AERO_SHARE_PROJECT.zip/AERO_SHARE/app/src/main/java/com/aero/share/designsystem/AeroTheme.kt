package com.aero.share.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object AeroColors {
    val BackgroundDark = Color(0xFF090909)
    val SurfaceDark = Color(0xFF141414)
    val SecondarySurfaceDark = Color(0xFF1C1C1C)
    val ElevatedSurfaceDark = Color(0xFF222222)
    val DividerDark = Color(0xFF303030)

    val OrangePrimary = Color(0xFFFF7900)
    val OrangeSecondary = Color(0xFFFF9A35)
    val TextMainDark = Color(0xFFFFFFFF)
    val TextMutedDark = Color(0xFFA3A3A3)

    val BackgroundLight = Color(0xFFF5F5F5)
    val SurfaceLight = Color(0xFFFFFFFF)
    val SecondarySurfaceLight = Color(0xFFEBEBEB)
    val TextMainLight = Color(0xFF111111)
    val TextMutedLight = Color(0xFF5A5A5A)
    val DividerLight = Color(0xFFD4D4D4)
}

private val DarkScheme = darkColorScheme(
    primary = AeroColors.OrangePrimary,
    onPrimary = Color(0xFF090909),
    secondary = AeroColors.OrangeSecondary,
    background = AeroColors.BackgroundDark,
    onBackground = AeroColors.TextMainDark,
    surface = AeroColors.SurfaceDark,
    onSurface = AeroColors.TextMainDark,
    surfaceVariant = AeroColors.SecondarySurfaceDark,
    onSurfaceVariant = AeroColors.TextMutedDark,
    outline = AeroColors.DividerDark
)

private val LightScheme = lightColorScheme(
    primary = AeroColors.OrangePrimary,
    onPrimary = Color.White,
    secondary = AeroColors.OrangeSecondary,
    background = AeroColors.BackgroundLight,
    onBackground = AeroColors.TextMainLight,
    surface = AeroColors.SurfaceLight,
    onSurface = AeroColors.TextMainLight,
    surfaceVariant = AeroColors.SecondarySurfaceLight,
    onSurfaceVariant = AeroColors.TextMutedLight,
    outline = AeroColors.DividerLight
)

val AeroShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

val AeroTypography = Typography(
    headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp),
    bodyMedium = TextStyle(fontSize = 13.sp, lineHeight = 18.sp)
)

@Composable
fun AeroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = AeroTypography,
        shapes = AeroShapes,
        content = content
    )
}
