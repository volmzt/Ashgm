package com.aero.share.transfer

import java.io.File

object PathValidator {
    fun sanitizeRelativePath(rawPath: String): String {
        require(rawPath.isNotBlank()) { "Path cannot be blank" }
        require('\u0000' !in rawPath) { "Null byte not allowed" }
        val parts = rawPath.replace('\\', '/').trim('/').split('/').filter { it.isNotEmpty() }
        require(parts.isNotEmpty()) { "Empty path segments" }
        require(parts.none { it == "." || it == ".." || it.contains(":") }) {
            "Unsafe path traversal detected"
        }
        return parts.joinToString(File.separator)
    }
}
