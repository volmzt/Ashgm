package com.aero.share

import com.aero.share.transfer.PathValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.File

class PathValidatorTest {
    @Test
    fun acceptsValidNestedPath() {
        val result = PathValidator.sanitizeRelativePath("Folder/SubFolder/photo.jpg")
        assertEquals("Folder${File.separator}SubFolder${File.separator}photo.jpg", result)
    }

    @Test
    fun rejectsTraversalPath() {
        assertThrows(IllegalArgumentException::class.java) {
            PathValidator.sanitizeRelativePath("../../etc/passwd")
        }
    }
}
