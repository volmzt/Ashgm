# AERO SHARE
Developer: AERO
Offline-first native Android file sharing platform built with Kotlin and Jetpack Compose.
